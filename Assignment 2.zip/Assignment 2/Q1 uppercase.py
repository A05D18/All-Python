"""Q. 1. Check if all letters in a string are uppercase"""
s = input("Enter your string...")
print(s.isupper())